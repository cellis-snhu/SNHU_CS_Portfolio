package com.example.chriselliseventtrackingapp;

import com.example.chriselliseventtrackingapp.EventDatabase.Event;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;


public class EventAdapter extends RecyclerView.Adapter<EventAdapter.EventViewHolder> {
    private List<Event> eventList;
    private EventDatabase eventDB;

    public EventAdapter(List<Event> eventList, EventDatabase eventDB) {
        this.eventList = eventList;
        this.eventDB = eventDB;
    }

    @Override
    public EventViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.event_items, parent, false);
        return new EventViewHolder(view);
    }

    @Override
    public void onBindViewHolder(EventViewHolder holder, int position) {
        Event event = eventList.get(position);
        holder.textEvent.setText(event.getEventName());
        holder.textDate.setText(event.getEventDate());

        holder.buttonModify.setOnClickListener(v -> {
            // Create an intent to navigate to AddModifyEventActivity and pass an eventId
            // to fill out the page
            Intent intent = new Intent(v.getContext(), AddModifyEventActivity.class);

            // Pass event details to AddModifyEventActivity
            intent.putExtra("eventIdData", event.getId());
            intent.putExtra("eventNameData", event.getEventName());
            intent.putExtra("eventDescriptionData", event.getEventDescription());
            intent.putExtra("eventDateData", event.getEventDate());
            intent.putExtra("eventTimeData", event.getEventTime());
            intent.putExtra("notifyData", event.isNotify());

            // Start the activity with the intent
            v.getContext().startActivity(intent);
        });

        holder.buttonDelete.setOnClickListener(v -> {
            eventDB.deleteEvent(event.getId());
            eventList.remove(position);
            notifyItemRemoved(position);
        });

    }

    @Override
    public int getItemCount() {
        return eventList.size();
    }

    public static class EventViewHolder extends RecyclerView.ViewHolder {
        public TextView textEvent;
        public TextView textDate;

        public Button buttonModify;

        public Button buttonDelete;

        public EventViewHolder(View itemView) {
            super(itemView);
            textEvent = itemView.findViewById(R.id.textEvent);
            textDate = itemView.findViewById(R.id.textDate);
            buttonModify = itemView.findViewById(R.id.buttonModify);
            buttonDelete = itemView.findViewById(R.id.buttonDelete);
        }
    }
}
