package com.example.chriselliseventtrackingapp;

import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.util.Log;
import android.widget.CompoundButton;
import android.Manifest;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;
import android.widget.Button;
import android.widget.TimePicker;
import androidx.core.view.ViewCompat;
import androidx.core.app.ActivityCompat;
import androidx.core.view.WindowInsetsCompat;
import java.time.LocalDate;
import android.content.SharedPreferences;

public class AddModifyEventActivity extends AppCompatActivity {
    private boolean formIsValid(EditText eventName, EditText eventDescription, DatePicker eventDatePicker) {
        // check eventName is not empty
        if (eventName.getText().toString().trim().isEmpty()) {
            Toast.makeText(this, "Event name field cannot be empty", Toast.LENGTH_SHORT).show();
            return false;
        }

        // check eventDescription is not empty
        if (eventDescription.getText().toString().trim().isEmpty()) {
            Toast.makeText(this, "Event description field cannot be empty", Toast.LENGTH_SHORT).show();
            return false;
        }

        // Get the date from the DatePicker
        int year = eventDatePicker.getYear();
        int month = eventDatePicker.getMonth() + 1; // month indexes Jan at 0 so need to add 1
        int dayOfMonth = eventDatePicker.getDayOfMonth();

        // Create a LocalDate object for easy validation
        LocalDate selectedDate = LocalDate.of(year, month, dayOfMonth);

        // Check if the selected date is before today
        if (selectedDate.isBefore(LocalDate.now())) {
            Toast.makeText(this, "Event date cannot be before today", Toast.LENGTH_SHORT).show();
            return false;
        }

        // timePicker only shows valid times, so it is not checked in this validator

        // when all validations pass, return true
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_modify_event);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.addModifyEvent), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Retrieve the event data passed from the Intent
        Intent intent = getIntent();
        // Check if intent is null to avoid NullPointerException
        if (intent == null) {
            Log.e("AddModifyEventActivity", "Intent is null. Cannot retrieve event data.");
            finish();
            return;
        }

        // Use variables to store data passed from the Intent
        int eventIdData = intent.getIntExtra("eventIdData", -1); // Default value is -1 if eventIdData doesn't exist
        String eventNameData = intent.getStringExtra("eventNameData");
        String eventDescData = intent.getStringExtra("eventDescriptionData");
        String eventDateData = intent.getStringExtra("eventDateData");
        String eventTimeData = intent.getStringExtra("eventTimeData");
        boolean notifyData = intent.getBooleanExtra("notifyData", false);



        // setup fields and buttons
        EditText eventName = findViewById(R.id.eventName);
        EditText eventDescription = findViewById(R.id.eventDescription);
        DatePicker eventDatePicker = findViewById(R.id.eventDatePicker);
        TimePicker timePicker = findViewById(R.id.timePicker);
        Switch notificationSwitch = findViewById(R.id.notificationSwitch);
        Button editPermissionsButton = findViewById(R.id.editPermissionsButton);
        Button cancelButton = findViewById(R.id.cancelButton);
        Button saveButton = findViewById(R.id.saveButton);

        // Populate the UI fields with the passed data
        if (eventNameData != null) {
            eventName.setText(eventNameData);
        }
        if (eventDescData != null) {
            eventDescription.setText(eventDescData);
        }
        if (eventDateData != null) {
            String[] dateParts = eventDateData.split("-"); // split date by hypens
            int year = Integer.parseInt(dateParts[0]);
            int month = Integer.parseInt(dateParts[1]) - 1; // Month is 0-indexed
            int day = Integer.parseInt(dateParts[2]);
            eventDatePicker.updateDate(year, month, day);
        }
        if (eventTimeData != null) {
            String[] timeParts = eventTimeData.split(":"); // split time by colon
            int hour = Integer.parseInt(timeParts[0]);
            int minute = Integer.parseInt(timeParts[1]);
            timePicker.setHour(hour);
            timePicker.setMinute(minute);
        }
        notificationSwitch.setChecked(notifyData); // Set the notification switch state


        notificationSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    // Check if SMS permission is granted
                    if (ActivityCompat.checkSelfPermission(AddModifyEventActivity.this, Manifest.permission.SEND_SMS)
                            != PackageManager.PERMISSION_GRANTED) {
                        // If permission is not granted, reset the switch and navigate to permissions page
                        notificationSwitch.setChecked(false);
                        Intent intent = new Intent(AddModifyEventActivity.this, SMSPermissionActivity.class);
                        startActivity(intent);
                        Toast.makeText(AddModifyEventActivity.this,
                                "Please enable SMS permissions to use notifications.",
                                Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        editPermissionsButton.setOnClickListener(v -> {
            // Navigate to SMSPermissionActivity
            Intent editIntent = new Intent(AddModifyEventActivity.this, SMSPermissionActivity.class);
            startActivity(editIntent);
        });

        // On cancel button click, return to EventPageActivity
        cancelButton.setOnClickListener(v -> {
            Intent cancelIntent = new Intent(AddModifyEventActivity.this, EventPageActivity.class);
            startActivity(cancelIntent);
            finish();
        });

        // On save button click, validate fields are filled out, then commit event changes to database.
        saveButton.setOnClickListener(v -> {
            if (formIsValid(eventName, eventDescription, eventDatePicker)) {
                // setup DB to insert by userId
                EventDatabase eventDB = new EventDatabase(this);

                /* Convert variable fields for DB insert */
                // get userId from SHaredPreferences
                int userId = getUserId();
                String eventNameString = eventName.getText().toString();
                String eventDescString = eventDescription.getText().toString();
                // Get the date from the DatePicker
                int year = eventDatePicker.getYear();
                int month = eventDatePicker.getMonth() + 1; // month indexes Jan at 0 so need to add 1
                int dayOfMonth = eventDatePicker.getDayOfMonth();

                // Create a LocalDate object for easy validation
                LocalDate eventDateLocalDate = LocalDate.of(year, month, dayOfMonth);
                LocalDate today = LocalDate.now();

                String eventDateString = eventDateLocalDate.toString();

                int hour = timePicker.getHour();
                int minute = timePicker.getMinute();

                String eventTimeString = String.format("%02d:%02d", hour, minute);

                // Check if it's a new event or update an existing one
                if (eventIdData == -1) {
                    // Insert a new event if eventId is -1
                    eventDB.insertEvent(userId, eventNameString, eventDescString, eventDateString, eventTimeString, false);
                } else {
                    // Update the event if eventId exists
                    eventDB.updateEvent(userId, eventNameString, eventDescString, eventDateString, eventTimeString, false, eventIdData);
                }

                Intent saveIntent = new Intent(AddModifyEventActivity.this, EventPageActivity.class);
                startActivity(saveIntent);
                finish();
            }
        });
    }

    private int getUserId() {
        SharedPreferences sharedPreferences = getSharedPreferences("user_session", MODE_PRIVATE);
        return sharedPreferences.getInt("user_id", -1); // return -1 when not found
    }

}