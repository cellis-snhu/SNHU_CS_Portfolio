package com.example.chriselliseventtrackingapp;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.content.Intent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.view.View;
import android.util.Log;
import android.content.SharedPreferences;

public class MainActivity extends AppCompatActivity {

    EventDatabase eventDB = new EventDatabase(this);
    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button signInButton;
    private Button registerButton;
    private static final String TAG = "MainActivity";
    private static final String PREF_NAME = "user_session";
    private static final String KEY_USER_ID = "user_id";




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        usernameEditText = findViewById(R.id.username);
        passwordEditText = findViewById(R.id.password);
        signInButton = findViewById(R.id.button);
        registerButton = findViewById(R.id.button2);

        // add the admin user for project testing
        eventDB.insertAdminUser();

        signInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString().trim();
                String password = passwordEditText.getText().toString().trim();


                if (eventDB.validateLogin(username, password)) {
                    int userId = eventDB.getUserIdByUsername(username);
                    saveUserId(userId);
                    Log.d("MainActivity", "UserId: " + userId);
                    Intent intent = new Intent(MainActivity.this, EventPageActivity.class);
                    startActivity(intent);
                    Log.d(TAG, "Login successful for username: " + username);
                } else {
                    Toast.makeText(MainActivity.this, "Invalid username or password.", Toast.LENGTH_SHORT).show();
                    Log.d(TAG, "Login failed for username: " + username);
                }
            }
        });

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString().trim();
                String password = passwordEditText.getText().toString().trim();

                Log.d(TAG, "Register button clicked");
                eventDB.insertUser(username, password);
            }
        });
    }

    private void saveUserId(int userId) {
        SharedPreferences sharedPreferences = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(KEY_USER_ID, userId);
        editor.apply();
    }
}