package com.example.chriselliseventtrackingapp;

import android.content.SharedPreferences;
import android.os.Bundle;
import com.example.chriselliseventtrackingapp.EventDatabase.Event;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.time.LocalDate;
import java.util.List;

public class EventPageActivity extends AppCompatActivity {
    // initialize db
    EventDatabase eventDB = new EventDatabase(this);
    private RecyclerView recyclerViewEvents;
    private EventAdapter eventAdapter;

    private List<Event> events;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_event_page);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.eventPage), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize RecyclerView
        recyclerViewEvents = findViewById(R.id.recyclerViewEvents);
        recyclerViewEvents.setLayoutManager(new LinearLayoutManager(this));

        // Setup Floating Action Button (FAB) to add events
        FloatingActionButton addEventButton = findViewById(R.id.addEventButton);
        addEventButton.setOnClickListener(view -> {
            // Navigate to AddModifyEventActivity to add a new event
            Intent intent = new Intent(EventPageActivity.this, AddModifyEventActivity.class);
            startActivity(intent);
        });

        // Load events from the database
        loadEvents();
    }

    private void loadEvents() {
        int userId = getUserId();
        // Fetch events from the database
        events = eventDB.getEvents(userId);
        if (events != null && !events.isEmpty()) {
            // Setup adapter with events from list
            eventAdapter = new EventAdapter(events, eventDB);
            recyclerViewEvents.setAdapter(eventAdapter);
        } else {
            // Show toast if no events are found
            Toast.makeText(this, "No events found!", Toast.LENGTH_SHORT).show();
        }
        // setup temp storage for notifications in sharedPreferences
//        LocalDate today = LocalDate.now();
        SharedPreferences sharedPreferences = getSharedPreferences("EventNotifications", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        // send SMS notif for an events that occur today
        for (Event event : events) {
            checkIsNotifiedAndSendNotification(sharedPreferences, event);
        }
        // apply shared preference changes
        editor.apply();
    }



    private void deleteEvent(int eventId, int position) {

        // Delete the event from the database
        eventDB.deleteEvent(eventId);

        // Remove the event from the list
        events.remove(position);

        // Notify the adapter that the item has been removed
        eventAdapter.notifyItemRemoved(position);
    }

    private int getUserId() {
        SharedPreferences sharedPreferences = getSharedPreferences("user_session", MODE_PRIVATE);
        return sharedPreferences.getInt("user_id", -1); // return -1 when not found
    }

    private void sendSmsNotification(String eventName, String eventDesc, int eventId) {
        // Log the intent creation to trigger the SMS
        Log.d("SMSNotif", "Sending SMS notification for event: " + eventName);

        Intent intent = new Intent(this, NotificationReceiver.class);

        // Pass the event details through the intent
        intent.putExtra("eventName", eventName);
        intent.putExtra("eventDesc", eventDesc);
        intent.putExtra("eventId", eventId);

        // Send the broadcast to trigger the SMS notification
        sendBroadcast(intent);
    }

    // checkIsNotified checks all events against the SharedPref storage of notified event keys
    private void checkIsNotifiedAndSendNotification(SharedPreferences sharedPreferences, Event event) {
        LocalDate today = LocalDate.now();
        String eventDate = event.getEventDate();

        if (today.toString().equals(eventDate)) {
            // Check if notification has already been sent for this event today
            String eventKey = "notification_sent_" + event.getId();
            SharedPreferences.Editor editor = sharedPreferences.edit();
            boolean isNotificationSent = sharedPreferences.getBoolean(eventKey, false);

            if (!isNotificationSent) {
                sendSmsNotification(event.getEventName(), event.getEventDescription(), event.getId());

                // mark notif as sent
                editor.putBoolean(eventKey, true);
                Log.d("SMSNotif", "Event " + event.getEventName() + "marked as sent.");
            }
            editor.apply();
        }
    }
}