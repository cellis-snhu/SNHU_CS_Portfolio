package com.example.chriselliseventtrackingapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;


public class EventDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "movies.db";
    private static final int DATABASE_VERSION = 2;

    public EventDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    private static final class UserTable {
        public static final String TABLE_USERS = "users";
        public static final String COLUMN_ID = "id";
        public static final String COLUMN_USERNAME = "username";
        public static final String COLUMN_PASSWORD = "password";

        // SQL query to create the users table
        private static final String TABLE_CREATE =
                "CREATE TABLE " + TABLE_USERS + " (" +
                        COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COLUMN_USERNAME + " TEXT, " +
                        COLUMN_PASSWORD + " TEXT);";
    }

    private static final class EventTable {
        public static final String TABLE_NAME = "events";

        public static final String COLUMN_ID = "id";
        public static final String COLUMN_EVENT_NAME = "event_name";
        public static final String COLUMN_EVENT_DESCRIPTION = "event_description";
        public static final String COLUMN_EVENT_DATE = "event_date";
        public static final String COLUMN_EVENT_TIME = "event_time";
        public static final String COLUMN_NOTIFY = "notify";
        public static final String COLUMN_USER_ID = "user_id";  // New column to tie events to users

        // SQL query to create events table
        public static final String CREATE_TABLE =
                "CREATE TABLE " + TABLE_NAME + " (" +
                        COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COLUMN_EVENT_NAME + " TEXT, " +
                        COLUMN_EVENT_DESCRIPTION + " TEXT, " +
                        COLUMN_EVENT_DATE + " TEXT, " +  // Store the date as a string (e.g., yyyy-MM-dd)
                        COLUMN_EVENT_TIME + " TEXT, " +  // Store the time as a string (e.g., HH:mm)
                        COLUMN_NOTIFY + " INTEGER DEFAULT 0, " +  // Store the notify as an integer (0 or 1) for boolean
                        COLUMN_USER_ID + " INTEGER, " +  // Foreign key reference to the users table
                        "FOREIGN KEY(" + COLUMN_USER_ID + ") REFERENCES " + UserTable.TABLE_USERS + "(" + UserTable.COLUMN_ID + ")" +
                        ");";

    }

    /***
     Helper functions for getting info from the DB
     ***/
    public int getUserIdByUsername(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        // Query to get user_id by username
        String query = "SELECT " + UserTable.COLUMN_ID + " FROM " + UserTable.TABLE_USERS +
                " WHERE " + UserTable.COLUMN_USERNAME + " = ?";
        String[] selectionArgs = {username};

        Cursor cursor = db.rawQuery(query, selectionArgs);

        // Check the column exists to avoid handling -1 value on non-existent columns
        if (cursor.moveToFirst()) {
            int columnIndex = cursor.getColumnIndex(UserTable.COLUMN_ID);

            if (columnIndex != -1) {
                // get the user's id
                int userId = cursor.getInt(columnIndex);
                cursor.close();
                db.close();
                return userId;
            }
        }

        // If no user found, close connections and exit
        cursor.close();
        db.close();
        return -1; // Use -1 as sentinel for user not found
    }


    public boolean validateLogin(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + UserTable.TABLE_USERS +
                " WHERE " + UserTable.COLUMN_USERNAME + " = ? AND " +
                UserTable.COLUMN_PASSWORD + " = ?";
        String[] selectionArgs = {username, password};

        Cursor cursor = db.rawQuery(query, selectionArgs);
        boolean isValid = cursor.getCount() > 0; // Check if any record matches
        cursor.close();
        db.close();

        return isValid;
    }

    public boolean doesUserExist(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        String checkQuery = "SELECT 1 FROM " + UserTable.TABLE_USERS +
                " WHERE " + UserTable.COLUMN_USERNAME + " = ?";
        Cursor cursor = db.rawQuery(checkQuery, new String[]{username});

        boolean userExists = cursor != null && cursor.moveToFirst();

        if (cursor != null) {
            cursor.close();
        }
        db.close();

        return userExists;
    }

    public void insertAdminUser() {

        if (doesUserExist("admin")) {
            Log.d("DB", "User already exists. Skipping insert.");
        } else {
            SQLiteDatabase db = this.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put(UserTable.COLUMN_USERNAME, "admin");
            values.put(UserTable.COLUMN_PASSWORD, "password123");

            db.insert(UserTable.TABLE_USERS, null, values);
            db.close();
        }
    }

    /***
     * Db operation functions
     ***/

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(UserTable.TABLE_CREATE);
        db.execSQL(EventTable.CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + UserTable.TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + EventTable.TABLE_NAME);
        onCreate(db);
    }

    public void insertUser(String username, String password) {
        if (doesUserExist(username)) {
            Log.d("DB", "User already exists. Skipping insert.");
        } else {

            SQLiteDatabase db = this.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put(UserTable.COLUMN_USERNAME, username);
            values.put(UserTable.COLUMN_PASSWORD, password);

            db.insert(UserTable.TABLE_USERS, null, values);
            db.close();
        }

    }

    public static class Event {
        private int id;
        private String eventName;
        private String eventDescription;
        private String eventDate;
        private String eventTime;
        private boolean notify;
        private int userId;

        public Event(int id, String eventName, String eventDescription,
                     String eventDate, String eventTime, boolean notify, int userId) {
            this.id = id;
            this.eventName = eventName;
            this.eventDescription = eventDescription;
            this.eventDate = eventDate;
            this.eventTime = eventTime;
            this.notify = notify;
            this.userId = userId;
        }

        // Getters and Setters
        public String getEventName() { return eventName; }
        public void setEventName(String eventName) { this.eventName = eventName; }

        public String getEventDescription() { return eventDescription; }
        public void setEventDescription(String eventDescription) { this.eventDescription = eventDescription; }

        public String getEventDate() { return eventDate; }
        public void setEventDate(String eventDate) { this.eventDate = eventDate; }

        public String getEventTime() { return eventTime; }
        public void setEventTime(String eventTime) { this.eventTime = eventTime; }

        public boolean isNotify() { return notify; }
        public void setNotify(boolean notify) { this.notify = notify; }

        public int getId() { return id; }
        public void setId(int id) { this.id = id; }

        public int getUserId() { return userId; }
        public void setUserId(int userId) { this.userId = userId; }
    }


    public void insertEvent(int userId, String eventName, String eventDescription, String eventDate, String eventTime, boolean notify) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(EventTable.COLUMN_EVENT_NAME, eventName);
        values.put(EventTable.COLUMN_EVENT_DESCRIPTION, eventDescription);
        values.put(EventTable.COLUMN_EVENT_DATE, eventDate);
        values.put(EventTable.COLUMN_EVENT_TIME, eventTime);
        values.put(EventTable.COLUMN_NOTIFY, notify ? 1 : 0);  // Convert boolean to 1 or 0
        values.put(EventTable.COLUMN_USER_ID, userId);  // Insert UserId foreign key

        db.insert(EventTable.TABLE_NAME, null, values);
        db.close();
    }

    public void updateEvent(int userId, String eventName, String eventDescription, String eventDate, String eventTime, boolean notify, int eventId) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(EventTable.COLUMN_EVENT_NAME, eventName);
        values.put(EventTable.COLUMN_EVENT_DESCRIPTION, eventDescription);
        values.put(EventTable.COLUMN_EVENT_DATE, eventDate);
        values.put(EventTable.COLUMN_EVENT_TIME, eventTime);
        values.put(EventTable.COLUMN_NOTIFY, notify ? 1 : 0);
        values.put(EventTable.COLUMN_USER_ID, userId);

        // Check if event with the given eventId exists
        String whereClause = EventTable.COLUMN_ID + " = ?";
        String[] whereArgs = new String[]{String.valueOf(eventId)};

        // Update the record if it exists
        int rowsUpdated = db.update(EventTable.TABLE_NAME, values, whereClause, whereArgs);

        if (rowsUpdated == 0) {

            values.put(EventTable.COLUMN_ID, eventId);
            db.insert(EventTable.TABLE_NAME, null, values);
        }

        db.close();
    }
    public List<Event> getEvents(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();

        // Query to fetch events for a specific user
        String query = "SELECT * FROM " + EventTable.TABLE_NAME +
                " WHERE " + EventTable.COLUMN_USER_ID + " = ?";
        String[] selectionArgs = {String.valueOf(userId)};

        Cursor cursor = db.rawQuery(query, selectionArgs);
        List<Event> events = new ArrayList<>();

        if (cursor != null && cursor.moveToFirst()) {
            do {
                // Safely fetch column indices
                int idIndex = cursor.getColumnIndex(EventTable.COLUMN_ID);
                int eventNameIndex = cursor.getColumnIndex(EventTable.COLUMN_EVENT_NAME);
                int eventDescriptionIndex = cursor.getColumnIndex(EventTable.COLUMN_EVENT_DESCRIPTION);
                int eventDateIndex = cursor.getColumnIndex(EventTable.COLUMN_EVENT_DATE);
                int eventTimeIndex = cursor.getColumnIndex(EventTable.COLUMN_EVENT_TIME);
                int notifyIndex = cursor.getColumnIndex(EventTable.COLUMN_NOTIFY);

                // Validate that column indices are not the -1 (not found) value
                int id = idIndex != -1 ? cursor.getInt(idIndex) : 0; // Default to 0 if column not found
                String eventName = eventNameIndex != -1 ? cursor.getString(eventNameIndex) : null;
                String eventDescription = eventDescriptionIndex != -1 ? cursor.getString(eventDescriptionIndex) : null;
                String eventDate = eventDateIndex != -1 ? cursor.getString(eventDateIndex) : null;
                String eventTime = eventTimeIndex != -1 ? cursor.getString(eventTimeIndex) : null;
                boolean notify = notifyIndex != -1 && cursor.getInt(notifyIndex) == 1;

                // Add to list
                events.add(new Event(id, eventName, eventDescription, eventDate, eventTime, notify, userId));
            } while (cursor.moveToNext());

            cursor.close();
        }

        db.close();
        return events;
    }

    public void deleteEvent(int eventId) {
        SQLiteDatabase db = this.getWritableDatabase();
        // Delete the event from the database based on its ID
        String whereClause = "id = ?";
        String[] whereArgs = { String.valueOf(eventId) };

        db.delete("events", whereClause, whereArgs);
    }
}
