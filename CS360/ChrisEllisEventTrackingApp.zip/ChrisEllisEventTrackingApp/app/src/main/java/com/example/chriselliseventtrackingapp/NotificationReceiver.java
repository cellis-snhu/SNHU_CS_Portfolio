package com.example.chriselliseventtrackingapp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.SmsManager;
import android.util.Log;

public class NotificationReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        int eventId = intent.getIntExtra("eventId", -1);
        String eventName = intent.getStringExtra("eventName");
        String eventPhoneNumber = "555-555-5555";

        // Log the received event details
        Log.d("SMSNotif", "Received event data: eventId=" + eventId + ", eventName=" + eventName);

        if (eventPhoneNumber != null && eventName != null) {
            Log.d("SMSNotif", "Sending SMS to " + eventPhoneNumber + " for " + eventName);
            SmsManager smsManager = SmsManager.getDefault();
            String message = "Reminder: " + eventName + " today!";
            smsManager.sendTextMessage(eventPhoneNumber, null, message, null, null);
        }
    }
}
